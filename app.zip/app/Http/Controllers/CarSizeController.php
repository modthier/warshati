<?php

namespace App\Http\Controllers;

use App\Models\CarSize;
use Illuminate\Http\Request;

class CarSizeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CarSize  $carSize
     * @return \Illuminate\Http\Response
     */
    public function show(CarSize $carSize)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CarSize  $carSize
     * @return \Illuminate\Http\Response
     */
    public function edit(CarSize $carSize)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CarSize  $carSize
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CarSize $carSize)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CarSize  $carSize
     * @return \Illuminate\Http\Response
     */
    public function destroy(CarSize $carSize)
    {
        //
    }
}
