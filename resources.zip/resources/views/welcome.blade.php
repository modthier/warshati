@extends('layouts.sneat')
@section('content')

@endsection
