<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\MediaCollections\Models\Media;


class Setting extends Model 
{
    

    protected $table = "settings";
   
    protected $guarded = [];
    
    
}
